package Hemtenta.Game;

/**
 * Main function file to initialize Game object
 */

public class  Main {

    public static void main(String[] args) {

       new GameInitializer();

    }
}
